import './app_data.dart';

class ApiFactory {
  static String loginApi = 'http://api.open-notify.org/astros';
  // AppData.baseUrl + "/api/login.json?response_format=true";
}
